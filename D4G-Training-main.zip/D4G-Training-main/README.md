# D4G-Training
## Installation

1. Make sure you installed `mySQL`
2. Copy the database in mySQL (create the database, then paste the dump to create the table)
3. Go to project’s root : `~/D4G-Training/`
4. Launch php server :

```bash
php -S localhost:<Desired Port> 
```